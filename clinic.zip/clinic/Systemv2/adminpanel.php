<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Appointment</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/profile.css">
    <link rel="stylesheet" href="css/editprofile.css">

    <!-- box-icon -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Font-icon -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <script>
        jQuery(function($){
            $("#edit-info-btn").click(function() {
                $("#editOverlay").fadeIn();
            });
            $("#closeForgotForm").click(function() {
                $("#editOverlay").fadeOut();
            });
            $(".edit-info-form").click(function(event){
                event.stopPropagation();
            });
        });
    </script>
</head>
<body>

    <div class="navigation">
        <nav>
            <a href="admin.php">
            <img src="images/logo.png" alt="logo" class="nav-logo">
            </a>
            <a href="logout.php" class="sign-out pull-right">
                <i class="fa fa-sign-out" style="color: white; margin:40px 20px 10px 20px ; font-size: 30px;"></i>
            </a>
        </nav>
    </div>
        
    <div class="userdash">
        <aside class="sidebar">
            <div class="menu">
                <div class="menu-content">
                    <div class="menu-name">Menu</div>
                </div>
                <i class='bx bx-menu' id="menu-btn"></i>
            </div>
            <ul class="nav-list">
                <li>
                    <a href="#">
                        <span class="material-symbols-outlined">account_circle</span>
                        <span class="link-name">Profile</span>
                    </a>
                </li>
                <li>
                    <a href="adminlist.php">
                        <span class="material-symbols-outlined">list</span>
                        <span class="link-name">Appointment List</span>
                    </a>
                </li>
            </ul> 
        </aside>
        <main class="profile-content">
            <?php
                // Assuming you have a database connection established
                include 'php/config.php';

                // Get the information of email and admin id from the admins table
                $sqlAdminInfo = "SELECT email, admin_id FROM admins";
                $resultAdminInfo = $conn->query($sqlAdminInfo);

                // Check if there are rows returned
                if ($resultAdminInfo->num_rows > 0) {
                    // Fetch the data
                    while ($rowAdminInfo = $resultAdminInfo->fetch_assoc()) {
                        $adminEmail = $rowAdminInfo['email'];
                        $adminId = $rowAdminInfo['admin_id'];

                        // You can use $adminEmail and $adminId as needed
                        echo "<div class='profile-card'>";
                        echo "<table class='admin-info'>";
                        echo "<h3 class='info-lbl'><span>Admin Information</span></h3>";
                        echo "<tbody>";
                        echo "<tr><td>Admin ID</td><td>:</td><td class='info'>$adminId</td></tr>";
                        echo "<tr><td>Email</td><td>:</td><td class='info'>$adminEmail</td></tr>";
                        echo "</tbody></table></div>";
                    }
                } else {
                    echo "No admin information found";
                }

                // Get the number of users from the table_users
$sqlUsers = "SELECT COUNT(*) as userCount FROM table_users";
$resultUsers = $conn->query($sqlUsers);
$rowUsers = $resultUsers->fetch_assoc();
$numberOfUsers = $rowUsers['userCount'];

// Get the number of schedules including cancelled, denied, and accepted ones from the bookings table
$sqlAllSchedules = "SELECT COUNT(*) as allScheduleCount FROM bookings";
$resultAllSchedules = $conn->query($sqlAllSchedules);
$rowAllSchedules = $resultAllSchedules->fetch_assoc();
$allSchedulesCount = $rowAllSchedules['allScheduleCount'];

// Get the number of cancelled schedules
$sqlCancelledSchedules = "SELECT COUNT(*) as cancelledScheduleCount FROM bookings WHERE status = 'Cancelled'";
$resultCancelledSchedules = $conn->query($sqlCancelledSchedules);
$rowCancelledSchedules = $resultCancelledSchedules->fetch_assoc();
$cancelledSchedulesCount = $rowCancelledSchedules['cancelledScheduleCount'];

// Get the number of denied schedules
$sqlDeniedSchedules = "SELECT COUNT(*) as deniedScheduleCount FROM bookings WHERE status = 'Denied'";
$resultDeniedSchedules = $conn->query($sqlDeniedSchedules);
$rowDeniedSchedules = $resultDeniedSchedules->fetch_assoc();
$deniedSchedulesCount = $rowDeniedSchedules['deniedScheduleCount'];

// Get the number of accepted schedules
$sqlAcceptedSchedules = "SELECT COUNT(*) as acceptedScheduleCount FROM bookings WHERE status = 'Accepted'";
$resultAcceptedSchedules = $conn->query($sqlAcceptedSchedules);
$rowAcceptedSchedules = $resultAcceptedSchedules->fetch_assoc();
$acceptedSchedulesCount = $rowAcceptedSchedules['acceptedScheduleCount'];

// Display the number of users and schedules
echo "<div class='profile-card'>";
echo "<table class='admin-info'>";
echo "<h3 class='info-lbl'><span>Statistics</span></h3>";
echo "<tbody>";
echo "<tr><td>Number of Users</td><td>:</td><td class='info'>$numberOfUsers</td></tr>";
echo "<tr><td>Number of Schedules</td><td>:</td><td class='info'>$allSchedulesCount</td></tr>";
echo "<tr><td>Number of Cancelled Schedules</td><td>:</td><td class='info'>$cancelledSchedulesCount</td></tr>";
echo "<tr><td>Number of Denied Schedules</td><td>:</td><td class='info'>$deniedSchedulesCount</td></tr>";
echo "<tr><td>Number of Accepted Schedules</td><td>:</td><td class='info'>$acceptedSchedulesCount</td></tr>";
echo "</tbody></table></div>";


                // Close the database connection
                $conn->close();
            ?>
        </main>
    </div>
    <script src="function.js"></script>
</body>
</html>
