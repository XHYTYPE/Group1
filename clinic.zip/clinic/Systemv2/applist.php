<?php
session_start(); 
include 'php/config.php';
if (!isset($_SESSION['id'])) {
    header("Location: login.php"); // Redirect to home page if not logged in
    exit();
}
function getAppointments() {
    global $conn;

    // Assuming you have stored user information in the session
    if (!isset($_SESSION['id'])) {
        // Handle the case where id is not set in the session
        return [];
    }

    $userId = $_SESSION['id'];

    $query = "SELECT
        bookings.id,
        bookings.name,
        bookings.status,
        slots.date AS slot_date,
        bookings.date AS appointment_date
    FROM
        bookings
    JOIN
        slots ON bookings.slot_id = slots.id
    WHERE
        bookings.user_id = $userId
    ORDER BY
        bookings.date ASC";

    $result = $conn->query($query);

    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    $appointments = [];

    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }

    return $appointments;
}


// Handle appointment cancellation
if (isset($_POST['cancel_button'])) {
    $appointmentId = $_POST['appointment_id'];

    $updateQuery = "UPDATE bookings SET status = 'Cancelled' WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("i", $appointmentId);

    if ($stmt->execute()) {
        echo "Appointment canceled successfully";
    } else {
        echo "Update failed: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
    exit(); // Make sure to exit after sending the response
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Appointment</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <!-- box-icon -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="css/list.css">
</head>

<body>
    <div class="navigation">
        <nav>
            <img src="images/logo.png" alt="logo" class="nav-logo">
            <a href="logout.php" class="sign-out pull-right">
                <i class="fa fa-sign-out" style="color: white; margin:40px 20px 10px 20px ; font-size: 30px;"></i>
            </a>
        </nav>
    </div>

    <div class="userdash">
        <aside class="sidebar">
            <div class="menu">
                <div class="menu-content">
                    <div class="menu-name">Menu</div>
                </div>
            <i class='bx bx-menu' id="menu-btn"></i>
            </div>
            <ul class="nav-list">
                <li>
                    <a href="Profile.php">
                        <span class="material-symbols-outlined">account_circle</span>
                        <span class="link-name">Profile</span>
                    </a>
                </li>
                <li>
                    <a href="calendar.php">
                        <span class="material-symbols-outlined">calendar_today</span>
                        <span class="link-name">Make an Appointment</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="material-symbols-outlined">list</span>
                        <span class="link-name">Appointment List</span>
                    </a>
                </li>
            </ul> 
        </aside>
    <div class="container">
        <div class="appointment-box">
            <h1 class="text-center">Appointment List</h1>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <table>
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Name</th>
                                <th>Booked Date</th>
                                <th>Cancel</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Fetch appointments from the database
                            $appointments = getAppointments();

                            foreach ($appointments as $appointment) {
                                $statusClass = ($appointment['status'] === 'Cancelled') ? 'canceled' : '';

                                echo '<tr>
                                    <td class="' . $statusClass . '">' . $appointment['status'] . '</td>
                                    <td>' . $appointment['name'] . '</td>
                                    <td>' . $appointment['slot_date'] . '</td>
                                    <td>
                                        <button onclick="cancelAppointment(' . $appointment['id'] . ')" class="btn btn-danger">Cancel</button>
                                    </td>
                                </tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- Add the JavaScript function here -->
    <script>
        let btn = document.querySelector("#menu-btn")
        let sidebar = document.querySelector(".sidebar");

        btn.onclick = function(){
            sidebar.classList.toggle("active");
        }
        function cancelAppointment(appointmentId) {
            if (confirm("Are you sure you want to cancel this appointment?")) {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        // Check the response and reload/update the table
                        if (xhr.responseText === "Appointment canceled successfully") {
                            location.reload();
                        } else {
                            alert("Error: " + xhr.responseText);
                        }
                    }
                };
                xhr.open("POST", window.location.href, true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.send("cancel_button=1&appointment_id=" + appointmentId);
            }
        }
    </script>
</body>

</html>
