-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2023 at 08:55 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinic_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `email`, `password`) VALUES
(1, 'mr.admin@gmail.com', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `slot_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `status` enum('Pending','Accepted','Denied','Cancelled') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `slot_id`, `user_id`, `name`, `address`, `age`, `email`, `date`, `status`) VALUES
(13, 1, 12, 'red', '0', 2, 'mr.red092697@gmail.com', '0000-00-00', 'Pending'),
(14, 1, 12, 'red', '0', 2, 'mr.red092697@gmail.com', '0000-00-00', 'Pending'),
(15, 1, 12, 'red', '0', 2, 'mr.red092697@gmail.com', '0000-00-00', 'Cancelled'),
(17, 4, 12, 'Red Amado', '13', 2, 'mr.red092697@gmail.com', '0000-00-00', 'Pending'),
(18, 4, 12, 'Red Amado', '13', 2, 'mr.red092697@gmail.com', '0000-00-00', 'Pending'),
(19, 2, 14, 'XUXHIA', '0', 13, 'xuxhia.maestre@gmail.com', '0000-00-00', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `slots`
--

CREATE TABLE `slots` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `booked_slots` int(11) DEFAULT 0,
  `total_slots` int(11) DEFAULT 50
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slots`
--

INSERT INTO `slots` (`id`, `date`, `booked_slots`, `total_slots`) VALUES
(1, '2023-12-05', 3, 50),
(2, '2023-12-06', 1, 50),
(3, '2023-12-07', 0, 50),
(4, '2023-12-08', 2, 50),
(5, '2023-12-09', 0, 50),
(6, '2023-12-10', 0, 50),
(7, '2023-12-15', 0, 50),
(8, '2023-12-16', 0, 50),
(9, '2023-12-17', 0, 50),
(10, '2023-12-18', 0, 50),
(11, '2023-12-19', 0, 50),
(12, '2023-12-20', 0, 50),
(13, '2023-12-25', 0, 50),
(14, '2023-12-26', 0, 50),
(15, '2023-12-27', 0, 50),
(16, '2023-12-28', 0, 50),
(17, '2023-12-29', 0, 50),
(18, '2023-12-30', 0, 50),
(19, '2024-01-04', 0, 50),
(20, '2024-01-05', 0, 50),
(21, '2024-01-06', 0, 50),
(22, '2024-01-07', 0, 50),
(23, '2024-01-08', 1, 50),
(24, '2024-01-09', 0, 50),
(25, '2024-01-14', 0, 50),
(26, '2024-01-15', 0, 50),
(27, '2024-01-16', 0, 50),
(28, '2024-01-17', 0, 50),
(29, '2024-01-18', 0, 50),
(30, '2024-01-19', 0, 50),
(31, '2024-01-24', 0, 50),
(32, '2024-01-25', 0, 50),
(33, '2024-01-26', 0, 50),
(34, '2024-01-27', 0, 50),
(35, '2024-01-28', 0, 50),
(36, '2024-01-29', 0, 50);

-- --------------------------------------------------------

--
-- Table structure for table `table_users`
--

CREATE TABLE `table_users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `otp` int(4) NOT NULL,
  `reset_code` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `table_users`
--

INSERT INTO `table_users` (`id`, `first_name`, `last_name`, `middle_name`, `birthdate`, `mobile_number`, `password`, `email`, `otp`, `reset_code`) VALUES
(12, 'r', 'd', 'e', '1997-09-26', '09164670954', '$2y$10$4Au95.gHRgVt0vfs/EoPB.sjlRHI3ViM3bRx1ZLwKVKW2Etg8SWxi', 'mr.red092697@gmail.com', 0, '89777270708'),
(13, 'Red', 'Amado', 'Burce', '1997-09-26', '0918396360', '$2y$10$QaEykS0ECiQGln8bQv3Ot.4za.r/acr8D5/EUZv4sF9eXVWXd3KXe', 'eamado261997@gmail.com', 0, NULL),
(14, 'xuxhia', 'corrae', 'na', '2003-04-07', '09354363562', '$2y$10$XFYTsyrPAaegI8jj4HVKWuiDkvbFD6b2oFplEeU7APca0UzBsU.q2', 'xuxhia.maestre@gmail.com', 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slot_id` (`slot_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `slots`
--
ALTER TABLE `slots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_users`
--
ALTER TABLE `table_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `slots`
--
ALTER TABLE `slots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `table_users`
--
ALTER TABLE `table_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`slot_id`) REFERENCES `slots` (`id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `table_users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
