<?php
include 'php/config.php';

// Function to sanitize input data
function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input
    $admin_id = sanitize_input($_POST["admin_id"]);
    $email = sanitize_input($_POST["email"]);
    $password = sanitize_input($_POST["password"]);

    // Query to check credentials (using plain text password)
    $sql = "SELECT * FROM admins WHERE admin_id = '$admin_id' AND email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Admin credentials are correct, redirect to the admin.php page
        header("Location: Admin.php");
        exit();
    } else {
        // Invalid credentials, set an error message
        $error = "Invalid admin credentials. Please try again.";
    }
}

// Close the database connection
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login Form</title>
    
    <link rel="stylesheet" href="css/style.css">
   

    
    <style>
        .content {
            background-image: url("images/bck.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: scroll;
            padding-top: 200px;
        }
    </style>
</head>

<body>
    <!-- Navigation bar -->
    <div class="navigation">
        <nav>
            <label class="logo1">BARANGAY</label><br>
            <label class="logo2">Health Center</label>
        </nav>
    </div>
    
    <!-- Login -->
    <div class="content">
        <img src="images/logo.png" alt="logo" class="logohome">
        <div class="container-login">
            <div class="login-form">
                <h3>ADMIN Login</h3>
                <form id="login-form" method="post" action="">
                    <div class="form-group">
                        <input type="text" placeholder="ADMIN ID" id="admin_id" name="admin_id" required>
                    </div>
                    <div class="form-group">
                        <input type="text" placeholder="EMAIL" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <input type="password" placeholder="PASSWORD" id="password" name="password" required>
                    </div>
                    
                    <button type="submit" id="login-btn">LOG IN</button>
                    <a href="home.php"><button type="button" id="login-btn">Go back</button></a>
                </form>
                
                <?php if (isset($error)) { ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php } ?>
            </div>
        </div>
    </div>
</body>
</html>
