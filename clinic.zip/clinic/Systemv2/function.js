//button-login
document.addEventListener('DOMContentLoaded', function () {
  const loginForm = document.getElementById('login-form');

  loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const email = document.getElementById('email').value; // Assuming your email input has the id 'email'
      const password = document.getElementById('password').value;

      // Perform AJAX request to log_process.php
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'php/log_process.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onreadystatechange = function () {
          if (xhr.readyState === XMLHttpRequest.DONE) {
              if (xhr.status === 200) {
                  // Successful response, you might want to handle it here
                  console.log(xhr.responseText);
              } else {
                  // Handle errors here
                  console.error('Error:', xhr.status, xhr.statusText);
              }
          }
      };
      xhr.send('email=' + encodeURIComponent(email) + '&password=' + encodeURIComponent(password));
  });
});





