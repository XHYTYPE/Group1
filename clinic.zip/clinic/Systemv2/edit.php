<?php
// Include the configuration file
include 'php/config.php';

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: home.php"); // Redirect to the home page if not logged in
    exit();
}

// Get the user ID from the session
$userId = $_SESSION['id'];

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save-info-btn'])) {
    // Get the edited information from the form
    $firstName = $_POST['firstName'];
    $middleName = $_POST['middleName'];
    $lastName = $_POST['lastName'];
    $birthDate = $_POST['birthDate']; // Assuming it's a valid date format
    $mobileNumber = $_POST['mobileNumber'];

    // Check if only letters are used in first name
    if (!ctype_alpha($firstName)) {
        echo "First Name should contain only letters.";
    }
    // Check if only letters are used in middle name
    elseif (!ctype_alpha($middleName)) {
        echo "Middle Name should contain only letters.";
    }
    // Check if only letters are used in last name
    elseif (!ctype_alpha($lastName)) {
        echo "Last Name should contain only letters.";
    }
    // Check if only numbers are used in mobile number
    elseif (!ctype_digit($mobileNumber)) {
        echo "Mobile Number should contain only numbers.";
    } else {
        // Check if the "email" key is set in the $_POST array
        $email = isset($_POST['email']) ? $_POST['email'] : '';

        // Update the user's information in the database
        $updateQuery = "UPDATE table_users SET 
                        first_name = ?, 
                        middle_name = ?, 
                        last_name = ?, 
                        birthdate = ?, 
                        mobile_number = ? 
                        WHERE id = ?";
        
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, "sssssi", $firstName, $middleName, $lastName, $birthDate, $mobileNumber, $userId);

        if (mysqli_stmt_execute($stmt)) {
            // Successfully updated the information
            echo "Information updated successfully!";
        } else {
            // Error updating information
            echo "Error updating information: " . mysqli_error($conn);
        }

        // Close the prepared statement
        mysqli_stmt_close($stmt);
    }
}

// Fetch the current user details from the database
$query = "SELECT * FROM table_users WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $userId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Check if the query was successful
if ($result && mysqli_num_rows($result) > 0) {
    $userDetails = mysqli_fetch_assoc($result);
} else {
    echo "Error fetching user details: " . mysqli_error($conn);
    exit();
}

// Close the prepared statement
mysqli_stmt_close($stmt);

// Close the database connection
mysqli_close($conn);
?>
