<?php

session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification Form</title>
    <link rel="stylesheet" href="css/otp.css" />
    <!-- Boxicons CSS -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <script src="script.js" defer></script>
</head>
<body>
    <div class="navigation">
        <!-- Navigation content -->
        <label class="logo1">BARANGAY</label><br>
        <label class="logo2">Health Center</label>
    </div>
    <div class="container">
        <header>
            <i class="bx bxs-check-shield"></i>
        </header>
        <h4>Enter OTP Code</h4>
        <form action="otp_function.php" method="POST" oninput="validateInput()">
            <div class="input-field">
                <input type="text" name="digit1" maxlength="1" required />
                <input type="text" name="digit2" maxlength="1" required />
                <input type="text" name="digit3" maxlength="1" required />
                <input type="text" name="digit4" maxlength="1" required />
            </div>
            <button type="submit" class="btn-53">
                <div class="original">VERIFY</div>
                <div class="letters">
                    <span>V</span>
                    <span>E</span>
                    <span>R</span>
                    <span>I</span>
                    <span>F</span>
                    <span>Y</span>
                </div>
            </button>
        </form>
    </div>

    <script>
        function validateInput() {
            // Get all input elements with type "text"
            var inputs = document.querySelectorAll('input[type="text"]');
            
            // Iterate through each input
            inputs.forEach(function(input) {
                // Remove non-numeric characters
                input.value = input.value.replace(/[^0-9]/g, '');
                
                // Ensure only one digit is present
                if (input.value.length > 1) {
                    input.value = input.value.charAt(0);
                }
            });
        }
    </script>
</body>
</html>
