<?php
session_start(); 
include 'php/config.php';

function getAppointments() {
    global $conn;
    
    $query = "SELECT
        bookings.id,
        bookings.name,
        bookings.status,
        slots.date AS slot_date,
        bookings.date AS appointment_date
    FROM
        bookings
    JOIN
        slots ON bookings.slot_id = slots.id
    ORDER BY
        bookings.date ASC";

    $result = $conn->query($query);

    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    $appointments = [];

    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }

    return $appointments;
}

// Handle appointment acceptance
if (isset($_POST['accept_button'])) {
    $appointmentId = $_POST['appointment_id'];

    $updateQuery = "UPDATE bookings SET status = 'Accepted' WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("i", $appointmentId);

    if ($stmt->execute()) {
        echo "Appointment accepted successfully";
    } else {
        echo "Update failed: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
    exit(); // Make sure to exit after sending the response
}

// Handle appointment denial
if (isset($_POST['deny_button'])) {
    $appointmentId = $_POST['appointment_id'];

    $updateQuery = "UPDATE bookings SET status = 'Denied' WHERE id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("i", $appointmentId);

    if ($stmt->execute()) {
        echo "Appointment denied successfully";
    } else {
        echo "Update failed: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
    exit(); // Make sure to exit after sending the response
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Appointment</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <!-- box-icon -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="css/list.css">
</head>

<body>
    <div class="navigation">
        <nav>
            <a href="admin.php">
            <img src="images/logo.png" alt="logo" class="nav-logo">
            </a>
            <a href="logout.php">
            <img src="images/signout.svg"alt="logo" class="nav-logo">
            </a>
        </nav>
    </div>

    <div class="userdash">
        <aside class="sidebar">
            <div class="menu">
                <div class="menu-content">
                    <div class="menu-name">Menu</div>
                </div>
            <i class='bx bx-menu' id="menu-btn"></i>
            </div>
            <ul class="nav-list">
                <li>
                    <a href="adminpanel.php">
                        <span class="material-symbols-outlined">account_circle</span>
                        <span class="link-name">Profile</span>
                    </a>
                </li>
                <li>
                    <a href="adminlist.php">
                        <span class="material-symbols-outlined">list</span>
                        <span class="link-name">Appointment List</span>
                    </a>
                </li>
            </ul> 
        </aside>
        <div class="container">
            <div class="appointment-box">
                <h1 class="text-center">Appointment List</h1>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <table>
                            <thead>
                                <tr>
                                    <th>Status</th>
                                    <th>Name</th>
                                    <th>Booked Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Fetch appointments from the database
                                $appointments = getAppointments();

                                foreach ($appointments as $appointment) {
                                    $statusClass = ($appointment['status'] === 'Cancelled') ? 'canceled' : '';

                                    echo '<tr>
                                        <td class="' . $statusClass . '">' . $appointment['status'] . '</td>
                                        <td>' . $appointment['name'] . '</td>
                                        <td>' . $appointment['slot_date'] . '</td>
                                        <td>
                                            <button onclick="acceptAppointment(' . $appointment['id'] . ')" class="btn btn-danger">Accept</button>
                                            <button onclick="denyAppointment(' . $appointment['id'] . ')" class="btn btn-danger">Deny</button>
                                        </td>
                                    </tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Add the JavaScript function here -->
    <script>
       

        function acceptAppointment(appointmentId) {
            if (confirm("Are you sure you want to accept this appointment?")) {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        // Check the response and reload/update the table
                        if (xhr.responseText === "Appointment accepted successfully") {
                            location.reload();
                        } else {
                            alert("Error: " + xhr.responseText);
                        }
                    }
                };
                xhr.open("POST", window.location.href, true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.send("accept_button=1&appointment_id=" + appointmentId);
            }
        }

        function denyAppointment(appointmentId) {
            if (confirm("Are you sure you want to deny this appointment?")) {
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        // Check the response and reload/update the table
                        if (xhr.responseText === "Appointment denied successfully") {
                            location.reload();
                        } else {
                            alert("Error: " + xhr.responseText);
                        }
                    }
                };
                xhr.open("POST", window.location.href, true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.send("deny_button=1&appointment_id=" + appointmentId);
            }
        }
    </script>
</body>

</html>
