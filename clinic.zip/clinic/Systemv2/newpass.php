<?php

// Include your database connection code (config.php or similar)
include 'php/config.php';

function getEmailById($conn, $userId) {
    $getEmailQuery = "SELECT email FROM table_users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $getEmailQuery);
    mysqli_stmt_bind_param($stmt, 'i', $userId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $email);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    return $email;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email-forgot-pass'])) {
    // Enable error reporting for debugging
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Sanitize and validate input
    $userId = 1; // Replace this with your actual user ID retrieval logic
    $userEmail = getEmailById($conn, $userId);


    

    // Check if passwords match
    if ($_POST['newpass'] === $_POST['confirmnewpass']) {
        // Hash the new password before storing it in the database
        $hashedPassword = password_hash($_POST['newpass'], PASSWORD_DEFAULT);

        

        // Update the user's password in the database
        $updateQuery = "UPDATE table_users SET password = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'si', $hashedPassword, $userId);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo "Password changed successfully!";
        } else {
            echo "Error updating password in the database";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Passwords do not match";
    }
}

?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Appointment</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/forgotpass.css">

    <!--Icon-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Font-icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

    <style>
        .content {
            background-image: url("images/bck.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: scroll;
        }
    </style>
</head>

<body>
    <!--Navigation bar-->
    <div class="navigation">
        <nav>
            <label class="logo1">BARANGAY</label><br>
            <label class="logo2">Health Center</label>
        </nav>
    </div>

    <div class="content">
        <div class="container-forgotpass">
            <div class="forgotpass-form">
                <h3>Forgot Password?</h3>
                <hr style="border-color: #069952; margin-top: 20px;">
                <form id="forgotpass-form" action="" method="POST">
                 <div class="form-group-forgot">
    
    </div>
    <div class="form-group-forgot">
        <input type="password" placeholder="New Password" id="newpass" name="newpass" required>
    </div>
    <div class="form-group-forgot">
        <input type="password" placeholder="Confirm New Password" id="confirmnewpass" name="confirmnewpass" required>
    </div>
    <hr style="border-color: #069952; margin-top: 20px;">
    <button type="submit" id="submit-forgotpass">SUBMIT</button>
    <a href="home.php"><button type="button">Go back</button></a>
</form>

            </div>
        </div>
    </div>

</body>

</html>
