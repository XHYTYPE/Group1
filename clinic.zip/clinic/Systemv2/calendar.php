<?php
session_start();
include 'php/config.php';
if (!isset($_SESSION['id'])) {
    header("Location: login.php"); // Redirect to home page if not logged in
    exit();
}
function connectToDatabase() {
    $mysqli = new mysqli('localhost', 'root', '', 'clinic_app');

    if ($mysqli->connect_error) {
        die('Connection failed: ' . $mysqli->connect_error);
    }

    return $mysqli;
}

function getBookings($month, $year) {
    $mysqli = connectToDatabase();
    $stmt = $mysqli->prepare("SELECT date FROM bookings WHERE MONTH(date) = ? AND YEAR(date) = ?");
    $stmt->bind_param('ss', $month, $year);
    $bookings = array();

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $bookings[] = $row['date'];
        }

        $stmt->close();
    }

    $mysqli->close();

    return $bookings;
}

function getAvailableSlotsForDate($date, $bookings, $slots) {
    // Check if the date is in the bookings array (i.e., already booked)
    if (in_array($date, $bookings)) {
        return 0; // No available slots if already booked
    }

    // Check if there are slots information for the given date
    if (isset($slots[$date])) {
        // Calculate available slots based on total slots and booked slots
        $totalSlots = $slots[$date]['total_slots'];
        $bookedSlots = $slots[$date]['booked_slots'];

        return max(0, $totalSlots - $bookedSlots);
    }

    // Default: If no information is available, assume all slots are available
    return 0;
}

function build_calendar($month, $year) {
    $bookings = getBookings($month, $year);

    $mysqli = connectToDatabase();
    $stmt = $mysqli->prepare("SELECT id, date, booked_slots, total_slots FROM slots WHERE MONTH(date) = ? AND YEAR(date) = ?");
    $stmt->bind_param('ss', $month, $year);
    $stmt->execute();
    $result = $stmt->get_result();

    $slots = array();
    while ($row = $result->fetch_assoc()) {
        $slots[$row['date']] = $row;
    }
    $stmt->close();

    $daysOfWeek = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
    $firstDayOfMonth = mktime(0, 0, 0, $month, 1, $year);
    $dateComponents = getdate($firstDayOfMonth);
    $monthName = $dateComponents['month'];
    $dayOfWeek = $dateComponents['wday'];

    $calendar = "<table class='table table-bordered'>";
    $calendar .= "<center><h2>$monthName $year</h2>";
    $calendar .= "<a class='btn btn-xs btn-primary' href='?month=" . date('m', mktime(0, 0, 0, $month-1, 1, $year)) . "&year=" . date('Y', mktime(0, 0, 0, $month-1, 1, $year)) . "'>Previous Month</a> ";
    $calendar .= " <a class='btn btn-xs btn-primary' href='?month=" . date('m') . "&year=" . date('Y') . "'>Current Month</a> ";
    $calendar .= "<a class='btn btn-xs btn-primary' href='?month=" . date('m', mktime(0, 0, 0, $month+1, 1, $year)) . "&year=" . date('Y', mktime(0, 0, 0, $month+1, 1, $year)) . "'>Next Month</a></center><br>";

    $calendar .= "<tr>";

    foreach ($daysOfWeek as $day) {
        $calendar .= "<th class='header'>" . substr($day, 0, 3) . "</th>";
    }

    $calendar .= "</tr><tr>";

    if ($dayOfWeek > 0) {
        for ($k = 0; $k < $dayOfWeek; $k++) {
            $calendar .= "<td class='empty'></td>";
        }
    }

    $currentDay = 1;

    while ($currentDay <= date('t', strtotime("$year-$month-$currentDay"))) {
        if ($dayOfWeek == 7) {
            $dayOfWeek = 0;
            $calendar .= "</tr><tr>";
        }
    
        $currentDayRel = str_pad($currentDay, 2, "0", STR_PAD_LEFT);
        $date = "$year-$month-$currentDayRel";
        $datetoday = date('Y-m-d');
    
        $availableSlots = getAvailableSlotsForDate($date, $bookings, $slots);
        $dayClass = ($date == $datetoday) ? 'today' : '';
    
        // Check if the date is before the current date
        if ($date < $datetoday) {
            $calendar .= "<td class='$dayClass'><h4>$currentDay</h4> <button class='btn btn-danger btn-xs'>N/A</button></td>";
        } else {
            // Disable booking on Saturdays and Sundays
            if ($dayOfWeek == 0 || $dayOfWeek == 6) {
                $calendar .= "<td class='$dayClass'><h4>$currentDay</h4></td>";
            } else {
                $calendar .= "<td class='$dayClass'><h4>$currentDay</h4>Slots: $availableSlots  <a href='book.php?date=" . $date . "' class='btn btn-success btn-xs'>Book</a></td>";
            }
        }
    
        $currentDay++;
        $dayOfWeek++;
    }
    

    if ($dayOfWeek != 7) {
        $remainingDays = 7 - $dayOfWeek;
        for ($l = 0; $l < $remainingDays; $l++) {
            $calendar .= "<td class='empty'></td>";
        }
    }

    $calendar .= "</tr>";
    $calendar .= "</table>";

    echo $calendar;
}

?>


<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <title>Barangay Appointment</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/calendar.css">
     <!-- box-icon -->
     <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
     <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

<body>
    <div class="navigation">
        <nav>
            <img src="images/logo.png" alt="logo" class="nav-logo">
            <a href="logout.php" class="sign-out pull-right">
                <i class="fa fa-sign-out" style="color: white; margin:40px 20px 10px 20px ; font-size: 30px;"></i>
            </a>
        </nav>
    </div>
    <div class="userdash">
        <aside class="sidebar">
            <div class="menu">
                <div class="menu-content">
                    <div class="menu-name">Menu</div>
                </div>
                <i class='bx bx-menu' id="menu-btn"></i>
            </div>
            <ul class="nav-list">
                <li>
                    <a href="Profile.php">
                        <span class="material-symbols-outlined">account_circle</span>
                        <span class="link-name">Profile</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="material-symbols-outlined">calendar_today</span>
                        <span class="link-name">Make an Appointment</span>
                    </a>
                </li>
                <li>
                    <a href="applist.php">
                        <span class="material-symbols-outlined">list</span>
                        <span class="link-name">Appointment List</span>
                    </a>
                </li>
            </ul>
        </aside>
        <main class="calendar-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <?php
                        $dateComponents = getdate();
                        if(isset($_GET['month']) && isset($_GET['year'])){
                            $month = $_GET['month'];
                            $year = $_GET['year'];
                        }else{
                            $month = $dateComponents['mon'];                             
                            $year = $dateComponents['year'];
                        }
                        echo build_calendar($month,$year);
                        ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        let btn = document.querySelector("#menu-btn")
        let sidebar = document.querySelector(".sidebar");

        btn.onclick = function () {
            sidebar.classList.toggle("active");
        }
    </script>

</body>

</html>
