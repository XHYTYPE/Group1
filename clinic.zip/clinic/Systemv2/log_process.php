<?php
// log_process.php

include 'php/config.php'; // Include your database connection
include 'otp_function.php';


if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["email"]) && isset($_POST["password"])) {
    // Validate and sanitize the email
    $email = filter_var($_POST["email"], FILTER_VALIDATE_EMAIL);

    if (!$email) {
        echo 'Invalid email address.';
        exit();
    }

    // Retrieve user input from the login form
    $password = $_POST["password"];
    $rememberMe = isset($_POST["rememberMe"]) ? $_POST["rememberMe"] : 0;

    // Perform login validation and database check using email
    $loginQuery = "SELECT * FROM table_users WHERE email = ?";
    $stmt = mysqli_prepare($conn, $loginQuery);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);

            // Verify password
            if (password_verify($password, $user["password"])) {
                // Password is correct, generate and store OTP
                $otp = generateOtp();
                storeOTP($conn, $user["id"], $otp);

                // Optionally, set a cookie for remember me
                if ($rememberMe) {
                    $hashedUserId = password_hash($user["id"], PASSWORD_DEFAULT);
                    setcookie("user_id", $hashedUserId, time() + (30 * 24 * 3600), "/");
                }

                // Set session variables
                $_SESSION['id'] = $user['id'];
                $_SESSION['email'] = $user['email'];

                // Redirect to a success page or perform further actions
                header("Location: otp.php");
                exit();
            } else {
                // Send an error response for invalid password
                echo 'Invalid password.';
            }
        } else {
            // Send an error response for email not found
            echo 'Email not found.';
        }
    } else {
        // Send an error response for database error
        echo 'Error: ' . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
} else {
    // Send an error response for invalid request
    echo 'Invalid request.';
}
?>
