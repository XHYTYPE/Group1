<?php
include 'php/config.php';

function connectToDatabase() {
    $mysqli = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

    if (!$mysqli) {
        die("DB connection failed: " . mysqli_connect_error());
    }

    return $mysqli;
} 

function getSlots($month, $year) {
    $mysqli = connectToDatabase();
    $stmt = $mysqli->prepare("SELECT id, date, booked_slots, total_slots FROM slots WHERE MONTH(date) = ? AND YEAR(date) = ?");
    $stmt->bind_param('ss', $month, $year);
    $stmt->execute();
    $result = $stmt->get_result();

    $slots = array();
    while ($row = $result->fetch_assoc()) {
        $slots[$row['date']] = $row;
    }

    $stmt->close();
    $mysqli->close();

    return $slots;
}

function getBookings($month, $year) {
    $mysqli = connectToDatabase();
    $stmt = $mysqli->prepare("SELECT id, user_id, slot_id, name, address, age, email, date, status FROM bookings WHERE MONTH(date) = ? AND YEAR(date) = ?");
    $stmt->bind_param('ss', $month, $year);
    $stmt->execute();
    $result = $stmt->get_result();

    $bookings = array();
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }

    $stmt->close();
    $mysqli->close();

    return $bookings;
}

function getAvailableSlotsForDate($date, $bookings, $slots) {
    $totalSlots = isset($slots[$date]['total_slots']) ? $slots[$date]['total_slots'] : 0;
    $bookedSlots = 0;

    foreach ($bookings as $booking) {
        if ($booking['date'] == $date) {
            $bookedSlots++;
        }
    }

    $availableSlots = $totalSlots - $bookedSlots;

    return [
        'available_slots' => $availableSlots,
        'slot_id' => isset($slots[$date]['id']) ? $slots[$date]['id'] : null,
    ];
}

function checkUserExists($userId) {
    $mysqli = connectToDatabase();
    $stmt = $mysqli->prepare("SELECT id FROM table_users WHERE id = ?");
    $stmt->bind_param('s', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $exists = $result->num_rows > 0;
    $stmt->close();
    return $exists;
}

session_start();

if (isset($_GET['date'])) {
    $date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $age = $_POST['age'];
    $email = $_POST['email'];

    $mysqli = connectToDatabase();

    // Assuming you have already validated user input
    if (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $msg = "<div class='alert alert-danger'>Invalid name format</div>";
    } elseif (!is_numeric($age) || $age <= 0) {
        // Validate age: must be a positive number
        $msg = "<div class='alert alert-danger'>Invalid age format</div>";
    } elseif (!preg_match("/^[a-zA-Z0-9, ]+$/", $address)) {
        // Validate address: allows alphanumeric characters and commas
        $msg = "<div class='alert alert-danger'>Invalid address format</div>";
    }
     elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match("/gmail\.com$/", $email)) {
        // Validate email: must be a valid email and end with gmail.com
        $msg = "<div class='alert alert-danger'>Invalid email format (must be a valid Gmail address)</div>";
    } else {
        $user_id = getCurrentUserID();

        // Check if the user exists
        if (!checkUserExists($user_id)) {
            // Redirect to login if the user does not exist
            header("Location: login.php");
            exit();
        }

        $bookings = getBookings(date('m', strtotime($date)), date('Y', strtotime($date)));
        $slots = getSlots(date('m', strtotime($date)), date('Y', strtotime($date)));

        $availableSlotsInfo = getAvailableSlotsForDate($date, $bookings, $slots);
        $availableSlots = $availableSlotsInfo['available_slots'];
        $slot_id = $availableSlotsInfo['slot_id'];

        $date = date('Y-m-d');
        // Check if there are available slots
        if ($availableSlots > 0) {
            // Proceed with the booking and insert $slot_id into the bookings table
            $stmt = $mysqli->prepare("INSERT INTO bookings (user_id, slot_id, name, address, age, email, date, status) VALUES (?,?,?,?,?,?,?,?)");
            $status = 'pending'; // You can set the initial status as 'pending'
            $stmt->bind_param('iisissis', $user_id, $slot_id, $name, $address, $age, $email, $date, $status);
            $stmt->execute();
            $msg = "<div class='alert alert-success'>Booking Successful!";
            $stmt->close();
            // Update the booked_slots in the slots table
            if ($slot_id !== null) {
                $mysqli->query("UPDATE slots SET booked_slots = booked_slots + 1 WHERE id = $slot_id");
            }
        } else {
            $msg = "<div class='alert alert-danger'>No available slots for the selected date</div>";
        }
    }
    $mysqli->close();
}

function getCurrentUserID() {
    // Check if the user is logged in
    if (!isset($_SESSION['id'])) {
        // If not logged in, redirect to home page or handle as needed
        header("Location: home.php");
        exit();
    }

    // If logged in, return the user ID
    return $_SESSION['id'];
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Appointment</title>
    <link rel="stylesheet" href="css/book.css">
</head>

<body>
    <div class="container">
        <h1 class="text-center">Book for Date: <?php echo date('m/d/Y', strtotime($date)); ?></h1><hr>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
            
                <form action="" method="post" autocomplete="off">
                <?php echo isset($msg) ? $msg : ''; ?>
                    <div class="form-group">
                        <label for="">Name of Patient</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="">Address</label>
                        <input type="text" class="form-control" name="address" required>
                    </div>
                    <div class="form-group">
                        <label for="">Age</label>
                        <input type="number" class="form-control" name="age" required>
                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
