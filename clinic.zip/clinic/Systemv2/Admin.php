<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Appointment</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/profile.css">
    <link rel="stylesheet" href="css/editprofile.css">
     <!-- box-icon -->
     <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
     <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
     
</head>
<body>
    <div class="navigation">
        <nav>
            <img src="images/logo.png" alt="logo" class="nav-logo">
            <a href="logout.php">
            <img src="images/signout.svg"alt="logo" class="nav-logo">
            </a>
        </nav>
    </div>
    <div class="userdash">
        <aside class="sidebar">
            <div class="menu">
                <div class="menu-content">
                    <div class="menu-name">Menu</div>
                </div>
            <i class='bx bx-menu' id="menu-btn"></i>
            </div>
            <ul class="nav-list">
                <li>
                    <a href="adminpanel.php">
                        <span class="material-symbols-outlined">account_circle</span>
                        <span class="link-name">Profile</span>
                    </a>
                </li>
                <li>
                    <a href="adminlist.php">
                        <span class="material-symbols-outlined">list</span>
                        <span class="link-name">Appointment List</span>
                    </a>
                </li>
            </ul> 
        </aside>
    </div>

    
    <script>
        let btn = document.querySelector("#menu-btn")
        let sidebar = document.querySelector(".sidebar");

        btn.onclick = function(){
            sidebar.classList.toggle("active");
        }
    </script>
</body>
</html>