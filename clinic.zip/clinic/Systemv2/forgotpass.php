<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';

include 'php/config.php';

function updateResetCode($conn, $email, $code) {
    $updateQuery = "UPDATE table_users SET reset_code = ? WHERE email = ?";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, 'ss', $code, $email);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $result;
}

function sendResetEmail($email, $code) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'mr.red092697@gmail.com';
        $mail->Password = 'ezoavahtxokotkbp';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Sender information
        $mail->setFrom('mr.red092697@gmail.com', 'BARANGAY HEALTH CARE CENTER'); // Change the sender name

        // Recipient email
        $mail->addAddress($email);

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset';
        $mail->Body = 'Click the following link to reset your password: <a href="http://localhost/clinic/Systemv2/newpass.php?reset=' . $code . '">Reset Password</a>';

        $mail->send();
        return true;
    } catch (Exception $e) {
        // Log the error or handle it accordingly
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Enable error reporting for debugging
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Check if the 'email-forgot-pass' key is set in $_POST
    if (isset($_POST['email-forgot-pass'])) {
        // Sanitize and validate input
        $email = mysqli_real_escape_string($conn, $_POST['email-forgot-pass']);

        // Check if the email exists in the database
        $checkEmailQuery = "SELECT email FROM table_users WHERE email = ?";
        $stmt = mysqli_prepare($conn, $checkEmailQuery);
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            // Email exists in the database, proceed with sending the reset email
            $code = rand(10000000000, 99999999999);
            $code = strval($code);

            if (updateResetCode($conn, $email, $code)) {
                if (sendResetEmail($email, $code)) {
                    echo "Message has been sent";
                } else {
                    echo "Error sending email";
                }
            } else {
                echo "Error updating reset code in the database";
            }
        } else {
            echo "This email address is not registered";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Email not provided in the form";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Appointment</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/forgotpass.css">
    
    <!--Icon-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Font-icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    
    <style>
        .content {
        background-image: url("images/bck.jpg");
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment:scroll;
        }
 </style>
    
</head>

<body>
    <!--Navigation bar-->
    <div class="navigation">
        <nav>
            <label class="logo1">BARANGAY</label><br>
            <label class="logo2">Health Center</label>
        </nav>
    </div>

    <div class="content">
        <div class="container-forgotpass">
            <div class="forgotpass-form">
                <h3>Forgot Password?</h3>
                <hr style="border-color: #069952; margin-top: 20px;">
                <form id="forgotpass-form" action="" method="POST">
                    <div class="form-group-forgot">
                        <input type="text" placeholder="EMAIL" id="email-forgot-pass" name="email-forgot-pass" required>
                    </div>
                    <hr style="border-color: #069952; margin-top: 20px;">
                    <button type="submit" id="submit-forgotpass">SUBMIT</button>
                    <button type="submit" id="go-back-btn"><a href="home.php">Go back</a></button>
                </form>
            </div>
        </div>
    </div>

</body>
</html>
