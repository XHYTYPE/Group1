<?php

// Include the configuration file
include 'php/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    handleOTPVerification($conn);
}

function handleOTPVerification($conn) {
    // Retrieve user input from the OTP form
    $digit1 = isset($_POST["digit1"]) ? $_POST["digit1"] : '';
    $digit2 = isset($_POST["digit2"]) ? $_POST["digit2"] : '';
    $digit3 = isset($_POST["digit3"]) ? $_POST["digit3"] : '';
    $digit4 = isset($_POST["digit4"]) ? $_POST["digit4"] : '';

    // Concatenate digits to form the complete OTP
    $otp = $digit1 . $digit2 . $digit3 . $digit4;

    // Get user ID dynamically based on login session
    session_start();
    if (isset($_SESSION['id'])) {
        $userId = $_SESSION['id'];
    } else {
        echo "User not logged in.";
        return;
    }

    // Retrieve stored OTP from the table_users table
    $storedOtp = getStoredOtp($conn, $userId);

    // Compare the entered OTP with the stored OTP
    if ($otp == $storedOtp) {
        // OTP is correct, you can implement further actions here
        header("Location: Profile.php");

        // Call the function to sanitize and clear OTP after successful login
        $sanitizedOtp = sanitizeAndClearOTP($conn, $userId);

        // Now, $sanitizedOtp contains the sanitized OTP
        // You can use it as needed, for example, logging or displaying to the user
    } else {
        echo "Invalid OTP. Please try again.";
    }
}

function sanitizeAndClearOTP($conn, $userId) {
    // Sanitize and clear the stored OTP after successful login
    $updateQuery = "UPDATE table_users SET otp = NULL WHERE id = ?";
    $stmtUpdate = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmtUpdate, "i", $userId);
    mysqli_stmt_execute($stmtUpdate);

    if (!$stmtUpdate) {
        echo "Error updating OTP: " . mysqli_error($conn);
        return null;
    }

    return null;
}

function isValidDigit($digit) {
    // Validate that the input is a single digit (0-9)
    return is_numeric($digit) && strlen($digit) === 1 && $digit >= 0 && $digit <= 9;
}

function getStoredOtp($conn, $userId) {
    // Retrieve stored OTP from the table_users table
    $query = "SELECT otp FROM table_users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['otp'];
    } else {
        return false; // Handle the case where OTP retrieval fails
    }
}

function generateOtp() {
    return str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
}

function storeOtp($conn, $userId, $otp) {
    // Check if there's already an OTP record for the user in the table_users table
    $checkExistingQuery = "SELECT * FROM table_users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $checkExistingQuery);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $checkExistingResult = mysqli_stmt_get_result($stmt);

    $stmtInsert = null; // Define $stmtInsert at the beginning

    if ($checkExistingResult) {
        if (mysqli_num_rows($checkExistingResult) > 0) {
            // If there's an existing OTP record, update it
            $updateQuery = "UPDATE table_users SET otp = ? WHERE id = ?";
            $stmtUpdate = mysqli_prepare($conn, $updateQuery);
            mysqli_stmt_bind_param($stmtUpdate, "si", $otp, $userId);
            mysqli_stmt_execute($stmtUpdate);

            if (!$stmtUpdate) {
                echo "Error updating OTP: " . mysqli_error($conn);
            }
        } else {
            // If no existing OTP record, insert a new one
            $insertQuery = "INSERT INTO table_users (id, otp) VALUES (?, ?)";
            $stmtInsert = mysqli_prepare($conn, $insertQuery);
            mysqli_stmt_bind_param($stmtInsert, "si", $userId, $otp);
            mysqli_stmt_execute($stmtInsert);

            if (!$stmtInsert) {
                echo "Error inserting OTP: " . mysqli_error($conn);
            }
        }
    } else {
        echo "Error checking existing OTP: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
    if ($stmtInsert) {
        mysqli_stmt_close($stmtInsert);
    }
    // Note: $stmtUpdate does not need to be explicitly closed here
}

?>
