<?php

include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form is for registration
    if (isset($_POST["register"])) {
        handleRegistration($conn); // Pass the $conn variable to the function
    }
}

function handleRegistration($conn) {

    $firstName = isset($_POST["firstname"]) ? $_POST["firstname"] : "";
    $middleName = isset($_POST["middlename"]) ? $_POST["middlename"] : "";
    $lastName = isset($_POST["lastname"]) ? $_POST["lastname"] : "";
    $birthdate = isset($_POST["birthdate"]) ? $_POST["birthdate"] : "";
    $mobileNumber = isset($_POST["mobilenumber"]) ? $_POST["mobilenumber"] : "";
    $newEmail = isset($_POST["newemail"]) ? $_POST["newemail"] : "";
    $newPassword = isset($_POST["newpassword"]) ? $_POST["newpassword"] : "";
    $confirmPassword = isset($_POST["confirmpassword"]) ? $_POST["confirmpassword"] : "";

    // Validate the input
    if (!isValidName($firstName) || !isValidName($middleName) || !isValidName($lastName)) {
        echo 'Invalid name format. Names should consist of letters and spaces only.';
        return;
    }

    if (!ctype_digit($mobileNumber)) {
        echo 'Invalid mobile number format. Mobile number should consist of numbers only.';
        return;
    }

    if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL) || !endsWith($newEmail, '@gmail.com')) {
        echo 'Invalid email format. Please use a valid Gmail address.';
        return;
    }

    if (empty($newPassword) || empty($confirmPassword)) {
        echo 'Both password fields are required.';
        return;
    }

    if ($newPassword != $confirmPassword) {
        echo 'Passwords do not match.';
        return;
    }

    // Check if the email already exists in the database
    $emailCheckQuery = "SELECT * FROM table_users WHERE email = '$newEmail'";
    $emailCheckResult = mysqli_query($conn, $emailCheckQuery);

    if (mysqli_num_rows($emailCheckResult) > 0) {
        echo 'Email already exists. Please use a different email address.';
        return;
    }

    // Hash the password before storing it in the database for security
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Insert the user information into the database
    $insertQuery = "INSERT INTO table_users (first_name, middle_name, last_name, birthdate, mobile_number, email, password) VALUES ('$firstName', '$middleName', '$lastName', '$birthdate', '$mobileNumber', '$newEmail', '$hashedPassword')";

    if (mysqli_query($conn, $insertQuery)) {
        echo 'Registration successful!';
    } else {
        echo "Error: " . $insertQuery . "<br>" . mysqli_error($conn);
    }
}

function isValidName($name) {
    return preg_match("/^[a-zA-Z ]+$/", $name);
}

// Function to check if a string ends with a specific substring
function endsWith($haystack, $needle) {
    $length = strlen($needle);
    return $length === 0 || (substr($haystack, -$length) === $needle);
}

?>
