<?php
// Include the configuration file
include 'php/config.php';

// Start the session
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: home.php"); // Redirect to home page if not logged in
    exit();
}
function getPatientName($firstName, $middleName, $lastName) {
    // You can modify this as per your naming convention
    return $firstName . ' ' . $middleName . ' ' . $lastName;
}
// Function to get user details from the database
function getUserDetails($conn, $userId) {
    $query = "SELECT * FROM table_users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    } else {
        return false;
    }
}
// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: home.php"); // Redirect to home page if not logged in
    exit();
}

// Get the user ID from the session
$userId = $_SESSION['id'];

// Query to get user details from the database
$query = "SELECT * FROM table_users WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $userId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Check if the query was successful
if ($result && mysqli_num_rows($result) > 0) {
    $userDetails = mysqli_fetch_assoc($result);
} else {
    echo "Error fetching user details: " . mysqli_error($conn);
    exit();
}

// Close the prepared statement
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Appointment</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/profile.css">
    <link rel="stylesheet" href="css/editprofile.css">

     <!-- box-icon -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Font-icon -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <script>
        jQuery(function($){
    $("#edit-info-btn").click(function() {
      $("#editOverlay").fadeIn();
    });
    $("#closeForgotForm").click(function() {
      $("#editOverlay").fadeOut();
    });
    $(".edit-info-form").click(function(event){
      event.stopPropagation();
    });
  });
    </script>
</head>
<body>

    <div class="navigation">
        <nav>
            <img src="images/logo.png" alt="logo" class="nav-logo">
            <a href="logout.php" class="sign-out pull-right">
                <i class="fa fa-sign-out" style="color: white; margin:40px 20px 10px 20px ; font-size: 30px;"></i>
            </a>
        </nav>
    </div>
        
    <div class="userdash">
        <aside class="sidebar">
            <div class="menu">
                <div class="menu-content">
                    <div class="menu-name">Menu</div>
                </div>
            <i class='bx bx-menu' id="menu-btn"></i>
            </div>
            <ul class="nav-list">
                <li>
                    <a href="#">
                        <span class="material-symbols-outlined">account_circle</span>
                        <span class="link-name">Profile</span>
                    </a>
                </li>
                <li>
                    <a href="calendar.php">
                        <span class="material-symbols-outlined">calendar_today</span>
                        <span class="link-name">Make an Appointment</span>
                    </a>
                </li>
                <li>
                    <a href="applist.php">
                        <span class="material-symbols-outlined">list</span>
                        <span class="link-name">Appointment List</span>
                    </a>
                </li>
            </ul> 
        </aside>
        <main class="profile-content">
            <h3 class="patients-name"><?php echo getPatientName($userDetails['first_name'], $userDetails['middle_name'], $userDetails['last_name']); ?></h3>
            <!-- profile-card-info -->
            <div class="profile-card">
                <table class="patient-info">
                    <h3 class="info-lbl"><span>Patient Information</span></h3>
                    <tbody>
                    <tr>
                            <td>First Name</td>
                            <td>:</td>
                            <td class="info"><?php echo $userDetails['first_name']; ?></td>
                        </tr>
                        <tr>
                            <td>Middle Name</td>
                            <td>:</td>
                            <td class="info"><?php echo $userDetails['middle_name']; ?></td>
                        </tr>
                        <tr>
                            <td>Last Name</td>
                            <td>:</td>
                            <td class="info"><?php echo $userDetails['last_name']; ?></td>
                        </tr>
                        <tr>
                            <td>Birth Date</td>
                            <td>:</td>
                            <td class="info"><?php echo $userDetails['birthdate']; ?></td>
                        </tr>
                    </tbody>
                </table>
                <table class="patient-contact">
                    <h3 class="contact-lbl"><span>Contact details</span></h3>
                    <tbody>
                         <tr>
                            <td>Mobile Number</td>
                            <td>:</td>
                            <td class="contact"><?php echo $userDetails['mobile_number']; ?></td>
                         </tr>
                        <tr>
                            <td>Email</td>
                            <td>:</td>
                            <td class="contact"><?php echo $userDetails['email']; ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div>
                <button type="submit" id="edit-info-btn">EDIT INFORMATION</button>
            </div>
           <!-- edit profile -->
<div class="edit-profile-card" id="editOverlay">
    <div class="edit-info-form">
        <form method="post" action="edit.php">
            <table class="patient-info">
                <h4 class="edit-lbl">Edit Information</h4>
                <i class="fa fa-times-circle" id="closeForgotForm" style="font-size:24px"></i>
                <h3 class="info-lbl"><span>Patient Information</span></h3>
                <tbody>
                    <tr>
                        <td>First Name : </td>
                        <td class="info-edit"><input type="text" name="firstName"></td>
                    </tr>
                    <tr>
                        <td>Middle Name : </td>
                        <td class="info-edit"><input type="text" name="middleName"></td>
                    </tr>
                    <tr>
                        <td>Last Name :</td>
                        <td class="info-edit"><input type="text" name="lastName"></td>
                    </tr>
                    <tr>
                        <td>Birth Date : </td>
                        <td class="info-edit"><input type="date" name="birthDate"></td>
                    </tr>
                </tbody>
            </table>
            <table class="edit-patient-contact">
                <h3 class="contact-lbl"><span>Contact details</span></h3>
                <tbody>
                    <tr>
                        <td>Mobile Number :</td>
                        <td class="contact-edit"><input type="text" name="mobileNumber"></td>
                    </tr>
                </tbody>
            </table>
            <div>
                <button type="submit" name="save-info-btn" id="save-info-btn">SAVE</button>
            </div>
        </form>
    </div>
</div>
        </main>
    </div>
    <script src="function.js"></script>
</body>
</html>
